﻿namespace GameFifteens2
{
    partial class FormGame15
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel = new TableLayoutPanel();
            button15 = new Button();
            button14 = new Button();
            button13 = new Button();
            button12 = new Button();
            button11 = new Button();
            button10 = new Button();
            button9 = new Button();
            button8 = new Button();
            button7 = new Button();
            button6 = new Button();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            button0 = new Button();
            menu = new MenuStrip();
            menu_start = new ToolStripMenuItem();
            tableLayoutPanel.SuspendLayout();
            menu.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel
            // 
            tableLayoutPanel.BackColor = Color.WhiteSmoke;
            tableLayoutPanel.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel.ColumnCount = 4;
            tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel.Controls.Add(button15, 3, 3);
            tableLayoutPanel.Controls.Add(button14, 2, 3);
            tableLayoutPanel.Controls.Add(button13, 1, 3);
            tableLayoutPanel.Controls.Add(button12, 0, 3);
            tableLayoutPanel.Controls.Add(button11, 3, 2);
            tableLayoutPanel.Controls.Add(button10, 2, 2);
            tableLayoutPanel.Controls.Add(button9, 1, 2);
            tableLayoutPanel.Controls.Add(button8, 0, 2);
            tableLayoutPanel.Controls.Add(button7, 3, 1);
            tableLayoutPanel.Controls.Add(button6, 2, 1);
            tableLayoutPanel.Controls.Add(button5, 1, 1);
            tableLayoutPanel.Controls.Add(button4, 0, 1);
            tableLayoutPanel.Controls.Add(button3, 3, 0);
            tableLayoutPanel.Controls.Add(button2, 2, 0);
            tableLayoutPanel.Controls.Add(button1, 1, 0);
            tableLayoutPanel.Controls.Add(button0, 0, 0);
            tableLayoutPanel.Dock = DockStyle.Fill;
            tableLayoutPanel.Location = new Point(0, 24);
            tableLayoutPanel.Margin = new Padding(7);
            tableLayoutPanel.Name = "tableLayoutPanel";
            tableLayoutPanel.RowCount = 4;
            tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel.Size = new Size(484, 437);
            tableLayoutPanel.TabIndex = 0;
            // 
            // button15
            // 
            button15.BackColor = Color.Gainsboro;
            button15.Dock = DockStyle.Fill;
            button15.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Regular, GraphicsUnit.Point);
            button15.Location = new Point(368, 335);
            button15.Margin = new Padding(7);
            button15.Name = "button15";
            button15.Size = new Size(108, 94);
            button15.TabIndex = 15;
            button15.Tag = "15";
            button15.Text = "-";
            button15.UseVisualStyleBackColor = false;
            button15.Click += button15_Click;
            // 
            // button14
            // 
            button14.BackColor = Color.Gainsboro;
            button14.Dock = DockStyle.Fill;
            button14.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Regular, GraphicsUnit.Point);
            button14.Location = new Point(248, 335);
            button14.Margin = new Padding(7);
            button14.Name = "button14";
            button14.Size = new Size(105, 94);
            button14.TabIndex = 14;
            button14.Tag = "14";
            button14.Text = "-";
            button14.UseVisualStyleBackColor = false;
            button14.Click += button15_Click;
            // 
            // button13
            // 
            button13.BackColor = Color.Gainsboro;
            button13.Dock = DockStyle.Fill;
            button13.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Regular, GraphicsUnit.Point);
            button13.Location = new Point(128, 335);
            button13.Margin = new Padding(7);
            button13.Name = "button13";
            button13.Size = new Size(105, 94);
            button13.TabIndex = 13;
            button13.Tag = "13";
            button13.Text = "-";
            button13.UseVisualStyleBackColor = false;
            button13.Click += button15_Click;
            // 
            // button12
            // 
            button12.BackColor = Color.Gainsboro;
            button12.Dock = DockStyle.Fill;
            button12.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Regular, GraphicsUnit.Point);
            button12.Location = new Point(8, 335);
            button12.Margin = new Padding(7);
            button12.Name = "button12";
            button12.Size = new Size(105, 94);
            button12.TabIndex = 12;
            button12.Tag = "12";
            button12.Text = "-";
            button12.UseVisualStyleBackColor = false;
            button12.Click += button15_Click;
            // 
            // button11
            // 
            button11.BackColor = Color.Gainsboro;
            button11.Dock = DockStyle.Fill;
            button11.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Regular, GraphicsUnit.Point);
            button11.Location = new Point(368, 226);
            button11.Margin = new Padding(7);
            button11.Name = "button11";
            button11.Size = new Size(108, 94);
            button11.TabIndex = 11;
            button11.Tag = "11";
            button11.Text = "-";
            button11.UseVisualStyleBackColor = false;
            button11.Click += button15_Click;
            // 
            // button10
            // 
            button10.BackColor = Color.Gainsboro;
            button10.Dock = DockStyle.Fill;
            button10.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Regular, GraphicsUnit.Point);
            button10.Location = new Point(248, 226);
            button10.Margin = new Padding(7);
            button10.Name = "button10";
            button10.Size = new Size(105, 94);
            button10.TabIndex = 10;
            button10.Tag = "10";
            button10.Text = "-";
            button10.UseVisualStyleBackColor = false;
            button10.Click += button15_Click;
            // 
            // button9
            // 
            button9.BackColor = Color.Gainsboro;
            button9.Dock = DockStyle.Fill;
            button9.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Regular, GraphicsUnit.Point);
            button9.Location = new Point(128, 226);
            button9.Margin = new Padding(7);
            button9.Name = "button9";
            button9.Size = new Size(105, 94);
            button9.TabIndex = 9;
            button9.Tag = "9";
            button9.Text = "-";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button15_Click;
            // 
            // button8
            // 
            button8.BackColor = Color.Gainsboro;
            button8.Dock = DockStyle.Fill;
            button8.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Regular, GraphicsUnit.Point);
            button8.Location = new Point(8, 226);
            button8.Margin = new Padding(7);
            button8.Name = "button8";
            button8.Size = new Size(105, 94);
            button8.TabIndex = 8;
            button8.Tag = "8";
            button8.Text = "-";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button15_Click;
            // 
            // button7
            // 
            button7.BackColor = Color.Gainsboro;
            button7.Dock = DockStyle.Fill;
            button7.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Regular, GraphicsUnit.Point);
            button7.Location = new Point(368, 117);
            button7.Margin = new Padding(7);
            button7.Name = "button7";
            button7.Size = new Size(108, 94);
            button7.TabIndex = 7;
            button7.Tag = "7";
            button7.Text = "-";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button15_Click;
            // 
            // button6
            // 
            button6.BackColor = Color.Gainsboro;
            button6.Dock = DockStyle.Fill;
            button6.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Regular, GraphicsUnit.Point);
            button6.Location = new Point(248, 117);
            button6.Margin = new Padding(7);
            button6.Name = "button6";
            button6.Size = new Size(105, 94);
            button6.TabIndex = 6;
            button6.Tag = "6";
            button6.Text = "-";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button15_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.Gainsboro;
            button5.Dock = DockStyle.Fill;
            button5.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Regular, GraphicsUnit.Point);
            button5.Location = new Point(128, 117);
            button5.Margin = new Padding(7);
            button5.Name = "button5";
            button5.Size = new Size(105, 94);
            button5.TabIndex = 5;
            button5.Tag = "5";
            button5.Text = "-";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button15_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.Gainsboro;
            button4.Dock = DockStyle.Fill;
            button4.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Regular, GraphicsUnit.Point);
            button4.Location = new Point(8, 117);
            button4.Margin = new Padding(7);
            button4.Name = "button4";
            button4.Size = new Size(105, 94);
            button4.TabIndex = 4;
            button4.Tag = "4";
            button4.Text = "-";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button15_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.Gainsboro;
            button3.Dock = DockStyle.Fill;
            button3.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Regular, GraphicsUnit.Point);
            button3.Location = new Point(368, 8);
            button3.Margin = new Padding(7);
            button3.Name = "button3";
            button3.Size = new Size(108, 94);
            button3.TabIndex = 3;
            button3.Tag = "3";
            button3.Text = "-";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button15_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Gainsboro;
            button2.Dock = DockStyle.Fill;
            button2.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Location = new Point(248, 8);
            button2.Margin = new Padding(7);
            button2.Name = "button2";
            button2.Size = new Size(105, 94);
            button2.TabIndex = 2;
            button2.Tag = "2";
            button2.Text = "-";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button15_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Gainsboro;
            button1.Dock = DockStyle.Fill;
            button1.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(128, 8);
            button1.Margin = new Padding(7);
            button1.Name = "button1";
            button1.Size = new Size(105, 94);
            button1.TabIndex = 1;
            button1.Tag = "1";
            button1.Text = "-";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button15_Click;
            // 
            // button0
            // 
            button0.BackColor = Color.Gainsboro;
            button0.Dock = DockStyle.Fill;
            button0.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Regular, GraphicsUnit.Point);
            button0.Location = new Point(8, 8);
            button0.Margin = new Padding(7);
            button0.Name = "button0";
            button0.Size = new Size(105, 94);
            button0.TabIndex = 0;
            button0.Tag = "0";
            button0.Text = "-";
            button0.UseVisualStyleBackColor = false;
            button0.Click += button15_Click;
            // 
            // menu
            // 
            menu.Items.AddRange(new ToolStripItem[] { menu_start });
            menu.Location = new Point(0, 0);
            menu.Name = "menu";
            menu.Size = new Size(484, 24);
            menu.TabIndex = 1;
            menu.Text = "menuStrip1";
            // 
            // menu_start
            // 
            menu_start.Name = "menu_start";
            menu_start.Size = new Size(86, 20);
            menu_start.Text = "Начать игру";
            menu_start.Click += menu_start_Click;
            // 
            // FormGame15
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 224, 192);
            ClientSize = new Size(484, 461);
            Controls.Add(tableLayoutPanel);
            Controls.Add(menu);
            Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point);
            MainMenuStrip = menu;
            Name = "FormGame15";
            ShowIcon = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Пятнашки";
            Load += FormGame15_Load;
            tableLayoutPanel.ResumeLayout(false);
            menu.ResumeLayout(false);
            menu.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel;
        private Button button0;
        private Button button15;
        private Button button14;
        private Button button13;
        private Button button12;
        private Button button11;
        private Button button10;
        private Button button9;
        private Button button8;
        private Button button7;
        private Button button6;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
        private MenuStrip menu;
        private ToolStripMenuItem menu_start;
    }
}